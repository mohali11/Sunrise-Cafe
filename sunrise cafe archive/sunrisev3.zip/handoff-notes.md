# Sunrise Cafe & Bakery — handoff notes

Before launch, replace the demo materials:

- Add real cafe, menu, and Instagram photos in the `images` folder and update the matching image paths in `index.html`.
- Replace the Square placeholder with the real online ordering link.
- Add the cafe's real Yelp and Facebook page links.
- Replace the Formspree placeholder ID so newsletter signups reach the right account.
- Replace the mock address and stand-in map with the real business address and its Google Maps embed.
- The gallery currently reuses three demo photos twice; select six approved gallery photos if you want six unique tiles.

To request a change, send the exact text, link, photo, or section that needs updating, plus the replacement you want. For photos, include the intended section or menu item and the exact filename. The site can then be updated and redeployed from the `Sunrise-Cafe` folder through the site's Netlify **Deploys** tab.
