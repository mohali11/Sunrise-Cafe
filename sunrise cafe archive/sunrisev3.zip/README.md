# Sunrise Cafe & Bakery

## What was built
A responsive one-page cafe website for Sunrise Cafe & Bakery, with a bakery-forward menu, contact details, social gallery, customer reviews, and signup forms.

## File list
- `index.html` — page content, navigation, menu, gallery, contact/newsletter forms, and map.
- `styles.css` — responsive layout, typography, colors, and interaction states.
- `script.js` — mobile navigation, menu category filtering, testimonial controls, and newsletter submission feedback.
- `images/` — favicon and all cafe, menu, and Instagram images used by the page.
- `README.md` — this project and deployment guide.
- `handoff-notes.md` — launch checklist and instructions for sending updates.

## Features
- Contact form configured for Netlify Forms.
- Newsletter signup configured for Formspree.
- Google Maps embed for the listed Austin address.
- Six-image Instagram grid with a link to the cafe's Instagram account.
- Online ordering buttons for the Square ordering page.
- Menu category filter for All, Brunch, Bakery, and Drinks.
- Smooth in-page scrolling that respects reduced-motion settings.

## Open placeholders
- Square ordering URL is still `https://squareup.com/PLACEHOLDER`.
- Yelp and Facebook URLs are still placeholders (`#`).
- The Formspree form ID is still `PLACEHOLDER_FORM_ID`.
- The address and map are mock-company stand-ins and should be replaced with the real business location and map.
- The supplied food and cafe images are stock/demo photos; replace them with approved business photography before launch.
- The gallery reuses the three supplied gallery photos twice to fill six tiles.

## How to update content
- Edit menu names, prices, and descriptions in the Menu section of `index.html`.
- Edit opening times in the Hours area of the Visit/Contact section in `index.html`.
- Replace photos by placing approved image files in `images/` and updating the matching `src="images/filename"` in `index.html`. Keep filenames and paths in sync.

## How to redeploy on Netlify
Open the site's **Deploys** tab in Netlify and drag the `Sunrise-Cafe` folder into the deploy drop area. The folder should contain `index.html`, `styles.css`, `script.js`, and `images/` at its top level.
